#!/bin/bash

#This script just loops over a number (default is 25) and create a child account in your AWS organization.
#This is described further at https://docs.aws.amazon.com/organizations/latest/userguide/orgs_manage_accounts_create.html

#Please make sure you use an email address to which you have access.

#Please note that in most (but not all) email systems, a "+" makes everything else a comment
#so username+deepracer1@ and username+deepracer2@ both get delivered to the username@ account.
#this is how multiple AWS accounts can be created for the same email address.

# global variables
declare ROOT_ID
declare ROOT_ACCOUNT_ID
declare OU_ID
declare ATTENDEE_POLICY=DeepRacerWorkshopAttendeePolicy
declare ROLE_NAME=DeepRacerWorkshopRole

#be sure to populate the environment variables
check_env_variables() {
  local err_count=0
  echo "=== check environment variables ======================================="

  if [ -z ${NAMED_PROFILE+x} ]; then
    let "err_count+=1"
    echo "NAMED_PROFILE is unset"
  else
    echo "NAMED_PROFILE is set to '$NAMED_PROFILE'"
  fi

  if [ -z ${NUMBER_OF_CHILD_ACCOUNTS+x} ]; then
    let "err_count+=1"
    echo "NUMBER_OF_CHILD_ACCOUNTS is unset"
  else
    echo "NUMBER_OF_CHILD_ACCOUNTS is set to '$NUMBER_OF_CHILD_ACCOUNTS'"
  fi

  if [ -z ${EMAIL_ADDRESS_PREFIX+x} ]; then
    let "err_count+=1"
    echo "EMAIL_ADDRESS_PREFIX is unset"
  else
    echo "EMAIL_ADDRESS_PREFIX is set to '$EMAIL_ADDRESS_PREFIX'"
  fi

  if [ -z ${EMAIL_ADDRESS_SUFFIX+x} ]; then
    let "err_count+=1"
    echo "EMAIL_ADDRESS_SUFFIX is unset"
  else
    echo "EMAIL_ADDRESS_SUFFIX is set to '$EMAIL_ADDRESS_SUFFIX'"
  fi

  if [ -z ${ACCOUNT_NAME+x} ]; then
    let "err_count+=1"
    echo "ACCOUNT_NAME is unset"
  else
    echo "ACCOUNT_NAME is set to '$ACCOUNT_NAME'"
  fi

  if [ -z ${OU_ID+x} ]; then
    let "err_count+=1"
    echo "OU_ID is unset"
  else
    echo "OU_ID is set to '$OU_ID'"
  fi

  if [ -z ${DEEPRACER_ROLE+x} ]; then
    let "err_count+=1"
    echo "DEEPRACER_ROLE is unset"
  else
    echo "DEEPRACER_ROLE is set to '$DEEPRACER_ROLE'"
  fi

  if [ -z ${USE_SAGEMAKER+x} ]; then
    let "err_count+=1"
    echo "USE_SAGEMAKER is unset"
  else
    echo "USE_SAGEMAKER is set to '$USE_SAGEMAKER'"
  fi

  if (($err_count > 0)); then
     echo "$err_count environment variables are unset. Please set all the environment variables and restart."
     exit 1
  else
    echo "All environment variables set."
  fi
}

replace_text_in_file() {
  local FIND_TEXT=$1
  local REPLACE_TEXT=$2
  local SRC_FILE=$3

  sed -i.bak "s ${FIND_TEXT} ${REPLACE_TEXT} g" ${SRC_FILE}
  rm $SRC_FILE.bak
}

copy_templates() {
  echo ""
  echo "=== copy policy templates ============================================="
  # create policies - copy template files into the root dir
  cp ./templates/trust_policy_template.json ./trust_policy.json
  if (( "$USE_SAGEMAKER" = "true" )); then
    cp ./templates/sagemaker_policy_template.json ./policy.json
  else
    cp ./templates/deepracer_policy_template.json ./policy.json
  fi
  echo "Successfully copied templates to the working directory."
  # replace child_account_id placeholder with child account id
  replace_text_in_file "root_account_id" ${ROOT_ACCOUNT_ID} trust_policy.json
}

get_root_id() {
  echo ""
  ROOT_ID=$(aws organizations list-roots --profile ${NAMED_PROFILE} | jq -r '.Roots[].Id')
  if [ -z ${ROOT_ID+x} ]; then
     echo "Unable to obtain root id for organization '${OU_ID}'."
     exit 1
  else
     echo "Root Id: '$ROOT_ID'."
  fi

  ROOT_ACCOUNT_ID=$(aws organizations describe-organization --profile ${NAMED_PROFILE} | jq -r '.Organization.MasterAccountId')
  if [ -z ${ROOT_ACCOUNT_ID+x} ]; then
    echo "Unable to obtain root account for organization '${OU_ID}'."
    exit 1
  else
    echo "Root account id: '$ROOT_ACCOUNT_ID'."
  fi
}

update_permissions() {
  local child_account_id=$1
  assumed_role=$(aws sts assume-role --role-arn "arn:aws:iam::${child_account_id}:role/OrganizationAccountAccessRole" --role-session-name "AssumeRoleSession-$((1 + RANDOM % 10000))" --profile ${NAMED_PROFILE})

  RoleAccessKeyID=$(echo "${assumed_role}" | jq -r '.Credentials | .AccessKeyId ')
  RoleSecretKey=$(echo "${assumed_role}" | jq -r '.Credentials | .SecretAccessKey ')
  RoleSessionToken=$(echo "${assumed_role}" | jq -r '.Credentials | .SessionToken ')

  export AWS_ACCESS_KEY_ID=${RoleAccessKeyID}
  export AWS_SECRET_ACCESS_KEY=${RoleSecretKey}
  export AWS_SESSION_TOKEN=${RoleSessionToken}

  #echo $(aws sts get-caller-identity)
  echo "Successfully assumed role: 'OrganizationAccountAccessRole'"

  # detach and delete existing atendee policy - no update
  json=$(aws iam list-policies --scope Local )
  for arn in $(echo "${json}" | jq -r '.Policies[] | select (.PolicyName == "DeepRacerWorkshopAttendeePolicy" ) | .Arn ' ); do
    #detach policy
    result=$(aws iam detach-role-policy --role-name ${ROLE_NAME} --policy-arn ${arn} )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Detached '${ATTENDEE_POLICY}' policy from workshop role: '${ROLE_NAME}'"
    else
      echo "Unable to detach '${ATTENDEE_POLICY}' policy from workshop role: '${ROLE_NAME}'"
      echo ${result}
      exit $err_code
    fi

    result=$(aws iam delete-policy --policy-arn $arn )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Deleted attendee policy: '${ATTENDEE_POLICY}'"
    else
      echo "Unable to delete attendee policy: ${ATTENDEE_POLICY}"
      echo ${result}
      exit $err_code
    fi
  done

  # delete existing role
  json=$(aws iam list-roles )
  for arn in $(echo "${json}" | jq -r '.Roles[] | select (.RoleName == "DeepRacerWorkshopRole" ) | .Arn ' ); do
    json=$(aws iam delete-role --role-name ${ROLE_NAME} )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Deleted workshop role: '${ROLE_NAME}'"
    else
      echo "Unable to delete workshop role: '${ROLE_NAME}'"
      echo ${result}
      exit $err_code
    fi
  done

  # create Role
  result=$(aws iam create-role --role-name ${ROLE_NAME} --assume-role-policy-document file://trust_policy.json --max-session-duration 43200)
  err_code=$?
  if (( $err_code == 0 )); then
    echo "Created workshop role: '${ROLE_NAME}'"
  else
    echo "Unable to create workshop role: '${ROLE_NAME}'"
    echo ${result}
    exit $err_code
  fi

  # create policy for workshop
  result=$(aws iam create-policy --policy-name ${ATTENDEE_POLICY} --policy-document file://policy.json )
  err_code=$?
  if (( $err_code == 0 )); then
    echo "Created attendee policy: '${ATTENDEE_POLICY}'"
  else
    echo "Unable to create attendee policy: '${ATTENDEE_POLICY}''"
    echo ${result}
    exit $err_code
  fi

  # attach policy to role
  arn=$(echo "${result}" | jq -r '.Policy | .Arn ' )
  result=$(aws iam attach-role-policy --policy-arn $arn --role-name ${ROLE_NAME})
  err_code=$?
  if (( $err_code == 0 )); then
    echo "Attached '${ATTENDEE_POLICY}' policy to workshop role: '${ROLE_NAME}'"
  else
    echo "Unable to attach '${ATTENDEE_POLICY}' policy to workshop role: '${ROLE_NAME}'"
    echo ${result}
    exit $err_code
  fi
}

update_child_accounts() {
  clear
  check_env_variables
  get_root_id
  copy_templates

  echo ""
  echo "=== updating child accounts ==========================================="

  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
  echo "root id: $ROOT_ID"
  echo "profile: $NAMED_PROFILE"
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    echo "child: child_account_id"
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo "child here: $child_account_id"
      echo ""
      echo "--- update permissions for child account id: '${child_account_id}'."
      update_permissions ${child_account_id}
    fi
  done

  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo ""
      echo "--- update permissions for child account id: '${child_account_id}'."
      update_permissions ${child_account_id}
    fi
  done

  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
  echo ""
  echo "--- Successfully updated permissions for child accounts of '$ROOT_ACCOUNT_ID'."
  exit 0
}

update_child_accounts

#!/bin/bash

#This script calls the sagemaker cleanup python file.

#envionment variables are required as noted in the readme.

# global variables
declare ROOT_ID
declare ROOT_ACCOUNT_ID
declare OU_ID

#be sure to populate the environment variables
check_env_variables() {
  local err_count=0
  echo "=== check environment variables ======================================="

  if [ -z ${NAMED_PROFILE+x} ]; then
    let "err_count+=1"
    echo "NAMED_PROFILE is unset"
  else
    echo "NAMED_PROFILE is set to '$NAMED_PROFILE'"
  fi

  if [ -z ${OU_ID+x} ]; then
    let "err_count+=1"
    echo "OU_ID is unset"
  else
    echo "OU_ID is set to '$OU_ID'"
  fi

  if [ -z ${DEEPRACER_ROLE+x} ]; then
    let "err_count+=1"
    echo "DEEPRACER_ROLE is unset"
  else
    echo "DEEPRACER_ROLE is set to '$DEEPRACER_ROLE'"
  fi

  if (($err_count > 0)); then
     echo "$err_count environment variables are unset. Please set all the environment variables and restart."
     exit 1
  else
    echo "All environment variables set."
  fi
}

get_root_id() {
  echo ""
  ROOT_ID=$(aws organizations list-roots --profile ${NAMED_PROFILE} | jq -r '.Roots[].Id')
  if [ -z ${ROOT_ID+x} ]; then
     echo "Unable to obtain root id for organization '${OU_ID}'."
     exit 1
  else
     echo "Root Id: '$ROOT_ID'."
  fi

  ROOT_ACCOUNT_ID=$(aws organizations describe-organization --profile ${NAMED_PROFILE} | jq -r '.Organization.MasterAccountId')
  if [ -z ${ROOT_ACCOUNT_ID+x} ]; then
    echo "Unable to obtain root account for organization '${OU_ID}'."
    exit 1
  else
    echo "Root account id: '$ROOT_ACCOUNT_ID'."
  fi
}

assume_role() {
  local child_account_id=$1

  assumed_role=$(aws sts assume-role --role-arn "arn:aws:iam::${child_account_id}:role/OrganizationAccountAccessRole" --role-session-name "AssumeRoleSession-$((1 + RANDOM % 10000))" --profile ${NAMED_PROFILE})
  RoleAccessKeyID=$(echo "${assumed_role}" | jq -r '.Credentials | .AccessKeyId ')
  RoleSecretKey=$(echo "${assumed_role}" | jq -r '.Credentials | .SecretAccessKey ')
  RoleSessionToken=$(echo "${assumed_role}" | jq -r '.Credentials | .SessionToken ')

  export AWS_ACCESS_KEY_ID=${RoleAccessKeyID}
  export AWS_SECRET_ACCESS_KEY=${RoleSecretKey}
  export AWS_SESSION_TOKEN=${RoleSessionToken}
}

stop_notebook() {
  local child_account_id=$1

  assumed_role=$(aws sts assume-role --role-arn "arn:aws:iam::${child_account_id}:role/OrganizationAccountAccessRole" --role-session-name "AssumeRoleSession-$((1 + RANDOM % 10000))" --profile ${NAMED_PROFILE})
  RoleAccessKeyID=$(echo "${assumed_role}" | jq -r '.Credentials | .AccessKeyId ')
  RoleSecretKey=$(echo "${assumed_role}" | jq -r '.Credentials | .SecretAccessKey ')
  RoleSessionToken=$(echo "${assumed_role}" | jq -r '.Credentials | .SessionToken ')

  export AWS_ACCESS_KEY_ID=${RoleAccessKeyID}
  export AWS_SECRET_ACCESS_KEY=${RoleSecretKey}
  export AWS_SESSION_TOKEN=${RoleSessionToken}

  # stop notebook for client account
  json=$(aws sagemaker list-notebook-instances --status-equals InService )
  for name in $(echo "${json}" | jq -r '.NotebookInstances[] | .NotebookInstanceName ' ); do
    result=$(aws sagemaker stop-notebook-instance --notebook-instance-name $name )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Stopping notebook: '${name}/"
    else
      echo "Unable to stop notebook '${name}' for account '$child_account_id'."
      echo ${result}
      exit $err_code
    fi
  done
}

delete_notebook() {
  local child_account_id=$1
  assume_role $child_account_id

  # delete notebook for client account
  json=$(aws sagemaker list-notebook-instances )
  for name in $(echo "${json}" | jq -r '.NotebookInstances[] | .NotebookInstanceName ' ); do
    result=$(aws sagemaker delete-notebook-instance --notebook-instance-name $name )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Deleting notebook: '${name}."
    else
      echo "Unable to delete notebook '${name}' for account '$child_account_id'."
      echo ${result}
      exit $err_code
    fi
  done
}

count_running_notebook() {
  local child_account_id=$1
  assume_role $child_account_id

  local count=0
  json=$(aws sagemaker list-notebook-instances --status-equals InService )
  for name in $(echo "${json}" | jq -r '.NotebookInstances[] | .NotebookInstanceName ' ); do
    let "count+=1"
  done

  return $((count))
}

stop_sagemaker_job() {
  local child_account_id=$1
  assume_role $child_account_id

  # stop notebook for client account
  json=$(aws sagemaker list-training-jobs --status-equals InProgress )
  for name in $(echo "${json}" | jq -r '.TrainingJobSummaries[] | .TrainingJobName ' ); do
    result=$(aws sagemaker stop-training-job --training-job-name $name )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Stopping training job: '${name}/"
    else
      echo "Unable to stop training job '${name}' for account '$child_account_id'."
      echo ${result}
      exit $err_code
    fi
  done
}

cancel_robomaker_job() {
  local child_account_id=$1
  assume_role $child_account_id

  # stop notebook for client account
  json=$(aws robomaker list-simulation-jobs )
  for arn in $(echo "${json}" | jq -r '.simulationJobSummaries[] | select (.status == "Running") | .arn ' ); do
    result=$(aws robomaker cancel-training-job --job $arn )
    err_code=$?
    if (( $err_code == 0 )); then
      echo "Cancelling training job: '${name}/"
    else
      echo "Unable to cancel training job '${name}' for account '$child_account_id'."
      echo ${result}
      exit $err_code
    fi
  done
}

stop_all_notebooks() {
  local run_count=0

  echo ""
  echo "=== shutdown SageMaker notebooks ======================================"

  # make three attempts at shutdown
  for ((i=1; i<4; i++)); do
    #count InServer notebooks
    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        count_running_notebook $child_account_id
        count_child_accounts=$?
        let "run_count+=$count_child_accounts"
      fi
    done

    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        count_running_notebook $child_account_id
        count_child_accounts=$?
        let "run_count+=$count_child_accounts"
      fi
    done

    if (( $run_count == 0 )); then
      echo "All notebooks for child account id: '${child_account_id}' are stopped."
      return 0
    else
      echo "--- attempt $i at shutting down notebooks."
      echo "$count_child_accounts InService notebooks for child account id: '${child_account_id}'."
    fi

    # shutdown sagemaker notebooks for all child accounts
    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        echo ""
        echo "--- stop notebooks for child account id: '${child_account_id}'."
        stop_notebook ${child_account_id}
      fi
    done

    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        echo ""
        echo "--- stop notebooks for child account id: '${child_account_id}'."
        stop_notebook ${child_account_id}
      fi
    done

    echo ""
    echo "--- Sleep for 2 minutes to allow shutdown to proceed."
    sleep 120
  done

  echo ""
  echo "--- Completed shutdown of SageMaker notebooks for child accounts of OU '${OU_ID}'."
  echo ""
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
}

stop_all_sagemaker_jobs() {
  echo ""
  echo "=== shutdown SageMaker training jobs =================================="

  # shutdown sagemaker notebooks for all child accounts
  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo ""
      echo "--- stop sagemaker training jobs for child account id: '${child_account_id}'."
      stop_sagemaker_job ${child_account_id}
    fi
  done

  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo ""
      echo "--- stop sagemaker training jobs for child account id: '${child_account_id}'."
      stop_sagemaker_job ${child_account_id}
    fi
  done

  echo ""
  echo "--- Stopped SageMaker training jobs for child accounts of OU '${OU_ID}'."
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
}

cancel_all_robomaker_jobs() {
  echo ""
  echo "=== Cancel RoboMaker simulation jobs =================================="

  # shutdown sagemaker notebooks for all child accounts
  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo ""
      echo "--- cancel robomaker simulation jobs for child account id: '${child_account_id}'."
      cancel_robomaker_job ${child_account_id}
    fi
  done

  json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
  for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
    if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
      echo ""
      echo "--- cancel robomaker simulation jobs for child account id: '${child_account_id}'."
      cancel_robomaker_job ${child_account_id}
    fi
  done

  echo ""
  echo "---"
  echo "Stopped SageMaker training jobs for child accounts of OU '${OU_ID}'."
  echo ""
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
}

delete_all_notebooks() {
  local run_count=0

  echo ""
  echo "=== Delete SageMaker notebooks ========================================"

    # shutdown sagemaker notebooks for all child accounts
    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${ROOT_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        echo ""
        echo "--- deleting notebooks for child account id: '${child_account_id}'."
        delete_notebook ${child_account_id}
      fi
    done

    json=$(aws organizations list-children --child-type ACCOUNT --parent-id ${OU_ID} --profile ${NAMED_PROFILE})
    for child_account_id in $(echo "${json}" | jq -r '.Children[].Id'); do
      if (( ${child_account_id} != ${ROOT_ACCOUNT_ID} )); then
        echo ""
        echo "--- deleting notebooks for child account id: '${child_account_id}'."
        delete_notebook ${child_account_id}
      fi
    done

  echo ""
  echo "--- Deleted SageMaker notebooks for child accounts of OU '${OU_ID}'."
  unset AWS_ACCESS_KEY_ID AWS_SECRET_ACCESS_KEY AWS_SESSION_TOKEN
}

clean_child_accounts() {
  clear
  check_env_variables
  get_root_id
  stop_all_notebooks
  stop_all_sagemaker_jobs
  cancel_all_robomaker_jobs
  delete_all_notebooks

  echo ""
  echo "--- Successfully cleaned up SageMaker and RoboMaker for child accounts of '$OU_ID'."
  echo ""
  exit 0
}

clean_child_accounts
